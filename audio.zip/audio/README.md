# Audio Examples

The licenses and the origins of the audio files are as follows:

- `sir_duke_trumpet_slow.mp3` and `sir_duke_trumpet_fast.mp3` were recorded by Stefan Balke and are released under license [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
- `sir_duke_piano_slow.mp3` and `sir_duke_piano_fast.mp3`: performed by Oscar Dub, recorded by Steve Tjoa, 2017 July 25 at CCRMA, license [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
